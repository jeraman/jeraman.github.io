# Data Analysis
This folder contains files used in our data analysis. They are:

* **Analysis-script.r:** Exploratory data analysis script written in R language;
* **pilot:** Folder containing the data we collected in our pilot study with 6 people. Each person has had his/her data logged into a separated JSON file;
* **rawdata:** Main data reported in the paper. This study was done with 12 people, and each person has had his/her data logged into a separated JSON file;
* **image plot:** Folder containing a png images the plots we made from our data.
