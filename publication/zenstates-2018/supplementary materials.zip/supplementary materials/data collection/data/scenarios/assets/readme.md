
# Attention
For loading the implementations used in this experiment you are going to need:
- **Processing**: version 3.2.1, available [here](https://processing.org/download/);
- **Pd-extended**: version 0.43.4-extended, available [here](https://puredata.info/downloads/pd-extended);
- **ZenStates**: Right version can be found [here](https://github.com/qualified-self/cue-control/tree/user-study).
